<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'detmirshapkin' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'r<v02BL[Wuit>*#E~.O$Jxn|~:/|c d(bU=Z3VN-&=}[3ois[;M9-=Q{9W2MPAsu' );
define( 'SECURE_AUTH_KEY',  'vRt  FgKZia]1S;L2,(ru4=emxEjWnv.6BWF8G)VuWJrh&:ew5goyn{4CD0Z602<' );
define( 'LOGGED_IN_KEY',    '1EqK]fjCj/-0v<TJR)8~$Hr73Y%XT{5%u2GgR)q.3Y1m^} dmbT6fthoB[h%M|F~' );
define( 'NONCE_KEY',        'bG*I8/+eRvF(#3 1K4Gq88.$WXQRfhG0)0@0LZW&#DQUA,t}i:z5`vX]}c8!v_!w' );
define( 'AUTH_SALT',        '@o=H4bPMU?D)`h:eSR[|`qwd#Yk2T>.2c$hSt|/*zT|{mr}S<xIj6Z%nU?e@seD~' );
define( 'SECURE_AUTH_SALT', '//~8_-UHO(U.o0+h{2Y ,1bBKRLf&Cpoa{y+H,I0mj::;YzX4,3)$>s*7)FTP|`F' );
define( 'LOGGED_IN_SALT',   '{hOb]T0Q6At~p9=>-vjy~J0ir|V@Hyoo+g)*L+g{{~*N&%e`qW?PNV;G|>Kd#$i3' );
define( 'NONCE_SALT',       'zwP2(Z{h.&pqDfx;D~3:15Sw#c#RdbPoa5o2 }Sb+a@^(xi5NG>``)kmA]uF?rAi' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
